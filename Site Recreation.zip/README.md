
  # Site Recreation

  This is a code bundle for Site Recreation. The original project is available at https://www.figma.com/design/LQrgCCMhs1z79RQrFCWFR5/Site-Recreation.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  